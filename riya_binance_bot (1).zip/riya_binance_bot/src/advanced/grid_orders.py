print('Simulating Grid strategy...')
# Buy low/sell high logic using a loop
