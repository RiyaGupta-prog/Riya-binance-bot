import time
print('Simulating TWAP order...')
# Split order into smaller chunks
